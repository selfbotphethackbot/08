# -*- coding: utf-8 -*-
from api import *
from en import LINE
from api.services.ttypes import OpType,Message,TalkException
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from dateutil import parser
import os
import commands as com
import importlib
import sys
from threading import Thread, active_count
from api.settings import LineHeaders
import time
import json
import codecs
import glob
import re
import traceback
import pytz
import subprocess

letak = '/root/Smile/'
OT = OpType
resp = os.path.splitext(os.path.basename(__file__))[0]
with open("{}token/{}.json".format(letak,resp),'r') as fk:db = json.load(fk)
token = db["token"]
ipaddr = subprocess.getoutput('dig +short myip.opendns.com @resolver1.opendns.com')
try:
    app = 'ios'
    client = LineClient(token=token,device=app);print("Smile Login")
except TalkException as teror:
  if teror.code in [1,7]:
    app = 'windows'
    client = LineClient(id=mail,password=pasw,device=app);print("Secondary Login")
# elif teror.code == 20:
#    helper = LINE('u13ed7d0eeaad847330ea24a5aa0c5d6c:aWF0OiAxNTU1MTc3NDc5NzI1Cg==..iScCZoNyR6g3lSOzPtUjJW/97BU=',appName='IOS 8.16.1 Iphone7')
#    helper.sendText("ub838bcac8ddfc102b1c8be46a75c6dc4",'This bot {} ,in server {} is freezing\nWait for re run about 1 hour'.format(resp,ipaddr))
#    print('FREEZING')
    time.sleep(3600)
    python3 = sys.executable
    os.execl(python3, python3, *sys.argv)
apps = LineHeaders.get_header(LineHeaders,app)
uid = client.get_profile().mid
print("Name: {}\nUID: {}\nApp: {}\nIP: {}\n\nBOT NEW".format(client.profile.displayName,uid,apps,ipaddr))
mode = 1
starting = time.time()
#-----------------SETTINGS LOADS-----------------#
try:account = open('{}smiledata/{}.json'.format(letak,resp),'r')
except:open('{}smiledata/{}.json'.format(letak,resp),'w').write('{}');account = open('{}smiledata/{}.json'.format(letak,resp),'r')
sett = json.load(account)
commands = {'invite':{},'gparam':''}
settings = {'nuke':False,'atjoin':True,'blj':{},'reb': '','cancel':{},'cname':{},'dname':{},'rname': resp,'sname':'default','squad':'PRO BOT','protect':{},'namelock':{'on':1,'nama':''},'allowban':True,'spam':{},'ant':False,'lock':False,'mute':False,'antimode':False,'purge':False,'war': False,'mode1': False,'linkprotect':{},'kick':{}}
status = {'start':time.time(), 'ban':False, 'invite':False,'unban':False,'abot':False,'aadmin':False,'aowner':False,'expel':False,\
         'repeat':False,'astaff':False,'abl':False,'owner':[],'squad':[],'backup':{'all':[]},'admin':[],'gaccess': {},'wordban':[],'staff':[],'anti':[],\
         'bot':[],'squad':[],'blacklist':[],'picture':{},'cvp': False,'gpic':{'pic': '','vid': ''},'duedate':str(datetime.now()+relativedelta(months=1))}
if not 'commands' in sett.keys():sett['commands'] = commands;commands = sett['commands']
else:commands = sett['commands']
if not 'settings' in sett:sett['settings'] = settings;settings = sett['settings'];client.send_message("u38774f160c456bd56c2b9c7604f0c192",'New BOT Created')
else:settings = sett['settings']
if not 'status' in sett:sett['status'] = status;status = sett['status']
else:status = sett['status']
if not 'cname' in settings:
   settings['cname'] = {}
if not 'dname' in settings:
   settings['dname'] = {}
if settings['allowban'] == {}:
   settings['allowban'] = True
kickcount = 0
duedate = parser.parse(status['duedate'])
if datetime.now() < duedate:
    try:
      if not settings['mute']:client.send_message(settings['reb'], '「 Starting Up 」')
    except:pass
else:
    [client.send_message(peki,'Time to due\nBot will shuting down.') for peki in status['owner']]
    [client.send_message(peki,'Time to due\nBot will shuting down.') for peki in master]
    time.sleep(2)
    sys.exit()
def backupData():
    with open('{}smiledata/{}.json'.format(letak,resp), 'w') as fp:
         json.dump(sett, fp, sort_keys=True, indent=4)
backupData()
def cover(msg):
    coms = LINE(client.authToken,appName=apps)
    path = client.downloadObjectMsg(msg.id)
    try:
        path = client.downloadObjectMsg(msg.id)
        coms.updateProfileCover(path)
        client.sendMessage(msg.to_id, 'Success updating profile cover.')
    except:
      try:
        path = client.downloadObjectMsg(msg.id)
        coms.updateProfileCover(path)
        client.sendMessage(msg.to_id, 'Success updating profile cover.')
      except:
        try:
          path = client.downloadObjectMsg(msg.id)
          coms.updateProfileCover(path)
          client.sendMessage(msg.to_id, 'Success updating profile cover.')
        except Exception as e:
          client.send_message(msg.to_id,str(e))
coms = com.beta(uid=uid,namen=resp,client=client,sett=sett,awit=starting,mode=mode,app=apps,letak=letak,cover=cover)
def logError(text):
      try:
        tz = pytz.timezone('Asia/Jakarta')
        timeNow = datetime.now(tz=tz)
        timeHours = datetime.strftime(timeNow,'(%H:%M)')
        day = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday','Friday', 'Saturday']
        hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']
        bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
        inihari = datetime.now(tz=tz)
        hr = inihari.strftime('%A')
        bln = inihari.strftime('%m')
        for i in range(len(day)):
            if hr == day[i]: hasil = hari[i]
        for k in range(0, len(bulan)):
            if bln == str(k): bln = bulan[k-1]
        time = '{}, {} - {} - {} | {}'.format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
        with open('{}log/e{}'.format(letak,resp),'a') as error:
            error.write('\n[ {} ] {}'.format(str(time), text))
      except Exception as e:
        traceback.print_tb(e.__traceback__)
def refresh(msg):
  try:
    global coms
    importlib.reload(com)
    coms = com.beta(uid=uid,namen=resp,client=client,sett=sett,awit=starting,mode=mode,app=apps,letak=letak,cover=cover)
    if not settings["mute"]:client.sendMessage(msg.to_id,"Updating complete.")
    print("sukses")
  except Exception as e:
    e = traceback.format_exc()
    if not settings["mute"]:client.sendMessage(msg.to_id,"Something error with your script:\n\n{}".format(e))
master = ["u38774f160c456bd56c2b9c7604f0c192"]
def main_loop(op):
                global kickcount
                if op.type == OT.NOTIFIED_KICKOUT_FROM_GROUP:
                    coms.async_notified_kickout_from_group(op)
                elif op.type == OT.NOTIFIED_INVITE_INTO_GROUP:
                    coms.async_notified_invite_into_group(op)
                elif op.type == OT.NOTIFIED_ACCEPT_GROUP_INVITATION:
                    coms.async_notified_accept_group_invitation(op)
                elif op.type == OT.NOTIFIED_UPDATE_GROUP:
                    coms.async_notified_update_group(op)
                elif op.type == OT.ACCEPT_GROUP_INVITATION:
                    coms.async_accept_group_invitation(op)
                elif op.type == OT.NOTIFIED_CANCEL_INVITATION_GROUP:
                    coms.async_notified_cancel_invitation_group(op)
                elif op.type == OT.RECEIVE_MESSAGE:
                            if datetime.now() < duedate:
                                msg = op.message
                                coms.async_receive_message(op)
                                if msg.content_type == 0 and msg.text != None:
                                    if msg.text.lower() == "all update" or msg.text.lower() == settings["rname"]+" update" or msg.text.lower() == settings["sname"]+" update":
                                      if msg.from_id in master:
                                        if not settings["mute"]:client.sendMessage(msg.to_id,"Please wait...")
                                        print("update")
                                        refresh(msg)
                                    elif msg.text.lower() == "all kickcount" or msg.text.lower() == settings["rname"]+" kickcount" or msg.text.lower() == settings["sname"]+" kickcount":
                                      if msg.from_id in sett['status']['owner'] or msg.from_id in sett['status']['admin'] or msg.from_id == 'u38774f160c456bd56c2b9c7604f0c192':
                                        if not settings["mute"]:client.sendMessage(msg.to_id,"Count: {}".format(kickcount))
                            else:client.sendMessage("u38774f160c456bd56c2b9c7604f0c192", "Time to due\nBot will shuting down.");backupData();sys.exit()
                elif op.type == OT.NOTIFIED_LEAVE_GROUP:
                    coms.async_notified_leave_group(op)
                elif op.type == OT.NOTIFIED_READ_MESSAGE:
                    coms.async_notified_read_message(op)
                elif op.type == OT.KICKOUT_FROM_GROUP:
                    kickcount += 1
                coms.async_auto()

while 1:
        try:
            for op in client.long_poll():
                t1 = Thread(target = main_loop(op))
                t1.start()
        except Exception as e:
          e = traceback.format_exc()
          if "EOFError" in e:
              pass
          elif 'code=20' in e:
              backupData()
              time.sleep(5)
              python3 = sys.executable
              os.execl(python3, python3, *sys.argv)
#          elif 'code=7' in e:
#              backupData()
#              helper = LINE('u13ed7d0eeaad847330ea24a5aa0c5d6c:aWF0OiAxNTU1MTc3NDc5NzI1Cg==..iScCZoNyR6g3lSOzPtUjJW/97BU=',appName='IOS 8.16.1 Iphone7')
#             helper.sendText("ub838bcac8ddfc102b1c8be46a75c6dc4",'Error from bot {} ,in server {}\n\n{}'.format(resp,ipaddr,e))
#              sys.exit('AUTH FAILED')
          elif 'code=8' in e:
              backupData()
              time.sleep(5)
              python3 = sys.executable
              os.execl(python3, python3, *sys.argv)
          else:
            logError(e)
            print('error')
