# -*- coding: utf-8 -*-
from akad.ttypes import ApplicationType
import re

class Config():
    LINE_HOST_DOMAIN            = 'https://legy-jp.line.naver.jp'
    LINE_LOGIN_QUERY_PATH       = '/api/v4p/rs'
    LINE_AUTH_QUERY_PATH        = '/api/v4/TalkService.do'
    LINE_API_QUERY_PATH_FIR     = '/S4'
    LINE_POLL_QUERY_PATH_FIR    = '/P4'
    LINE_CERTIFICATE_PATH       = '/Q'

    EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")

    def __init__(self):
        self.APP_NAME = 'WIN10\t5.5.5\tWINDOWS\t5.5.5'