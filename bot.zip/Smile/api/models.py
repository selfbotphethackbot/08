# -*- coding: utf-8 -*-
from .services import ttypes
import json
from .settings import LineURL
import operator


class MessageContact:
    def __init__(self, d):
        self.name = d["displayName"]
        self.id = d["mid"]

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))


class MessageSticker:
    def __init__(self, d):
        self.id = d["STKID"]
        self.package_id = d["STKPKGID"]
        self.text = d["STKTXT"]
        self.type = "NORMAL_STICKER"
        if "STKOPT" in d:
            s_type = d["STKOPT"]
            if s_type == "A":
                self.type = "ACTION_STICKER"
            elif s_type == "PS":
                self.type = "POP_UP_STICKER"
            elif s_type == "S":
                self.type = "SOUND_STICKER"
            else:
                self.type = "UNKNOWN_STICKER:%s" % s_type
        self.version = d["STKVER"]

    def get_preview(self):
        return "http://dl.stickershop.line.naver.jp/products/0/0/%s/%s/WindowsPhone/stickers/%s.png" \
               % (self.version, self.package_id, self.id)

    def get_sound(self):
        if self.type in ["POP_UP_STICKER", "SOUND_STICKER"]:
            return "https://sdl-stickershop.line.naver.jp/stickershop/v1/sticker/%s/IOS/sticker_sound.m4a" % self.id
        else:
            return "This sticker has no sound"

    def get_info(self):
        return "ID:%s\nPACK_ID:%s\nVERSION:%s" % (self.id, self.package_id, self.version)

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))


class MessageNote:
    def __init__(self, d):
        self.loc_key = d["locKey"]
        self.cafe_id = d["cafeId"]
        self.service_type = d["serviceType"]
        self.post_end_url = d["postEndUrl"]
        try:
            self.text = d["text"]
        except:
            self.text = "sticker"

    def get_post_url(self):
        return "%s/%s/%s" % (LineURL().get_url(), self.service_type.lower(), self.post_end_url.replace("line://", ""))

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))


class MessageSharedPost:
    def __init__(self, d):
        self.loc_key = d["locKey"]
        self.service_type = d["serviceType"]
        self.post_end_url = d["postEndUrl"]
        self.text = d["text"]
        stuff = self.post_end_url.split("&")
        self.user_mid = stuff[0].replace("line://home/post?userMid=", "")
        self.post_id = stuff[1].replace("postId=", "")

    def get_post_url(self):
        return "%s/%s/%s" % (LineURL().get_url(), self.service_type.lower(), self.post_end_url.replace("line://", ""))

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))


class MessageAlbum:
    def __init__(self, d):
        self.loc_key = d["locKey"]
        self.cafe_id = d["cafeId"]
        self.name = d["albumName"]
        self.service_type = d["serviceType"]
        self.post_end_url = d["postEndUrl"]
        try:
            self.text = d["text"]
        except:
            pass

    def get_post_url(self):
        return "%s/%s/%s" % (LineURL().get_url(), self.service_type.lower(), self.post_end_url.replace("line://", ""))

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))


class LineMessage:

    def __init__(self, message, client):
        self.client = client
        self.id = message.id
        self.content_preview = message.contentPreview
        self.content_type = message.contentType
        self.created_time = message.createdTime
        self.delivered_time = message.deliveredTime
        self.from_id = message._from
        self.has_content = message.hasContent
        self.content_metadata = message.contentMetadata
        self.to_id = message.to
        self.to_type = message.toType
        if message.location is not None:
            self.location = message.location
        self.text = message.text
        self.mentionees = []
        if bool(message.contentMetadata):
            #if "displayName" in message.contentMetadata:
             #   self.contact = MessageContact(message.contentMetadata)
            if "MENTION" in message.contentMetadata:
                message.contentMetadata["MENTION"] = json.loads(message.contentMetadata["MENTION"])
                for m in message.contentMetadata["MENTION"]["MENTIONEES"]:
                    self.mentionees.append(m["M"])
            #elif "STKTXT" in message.contentMetadata:
            #    self.sticker = MessageSticker(message.contentMetadata)
            #elif "serviceType" in message.contentMetadata:
            #    s_type = message.contentMetadata["serviceType"]
            #    if s_type == "AB":
            #        self.album = MessageAlbum(message.contentMetadata)
            #    elif s_type in ["NT", "GB"]:
            #        self.note = MessageNote(message.contentMetadata)
            #    elif s_type == "MH":
            #        self.shared_post = MessageSharedPost(message.contentMetadata)
        if self.to_id.startswith("c") or self.to_id.startswith("r"):
            self.reply_id = self.to_id
        else:
            if self.to_id != self.client.profile.mid:
                self.reply_id = self.to_id
            else:
                self.reply_id = self.from_id

    def get_object_url(self):
        return "http://os.line.naver.jp/os/m/%s" % self.id

    def reply_message(self, text):
        return self.client.send_message(self.reply_id, text)

    def reply_sticker(self, sticker_id="13", sticker_package_id="1", sticker_version="100", sticker_text="[null]"):
        return self.client.send_sticker((self.reply_id, sticker_id, sticker_package_id, sticker_version, sticker_text))

    def reply_image(self, path):
        return self.client.send_image(self.reply_id, path)

    def reply_video(self, path):
        return self.client.send_video(self.reply_id, path)

    def reply_audio(self, path):
        return self.client.send_audio(self.reply_id, path)

    def reply_contact(self, mid):
        return self.client.send_contact(self.reply_id, mid)

    def reply_location(self, long, lat, address):
        return self.client.send_location(self.reply_id, long, lat, address)

    def __repr__(self):
        L = ['%s=%r' % (key, value) for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))


class LineBase(object):

    """
    MESSAGE METHODS
    """
    def send_message(self, to, text):
        message_object = ttypes.Message(to=to, text=text)
        self.client._send_message(message_object)

    def send_sticker(self, to, sticker_id="13", sticker_package_id="1", sticker_version="100", sticker_text="[null]"):
        message_object = ttypes.Message(to=to, text=None, contentType=ttypes.ContentType.STICKER, contentMetadata={
            'STKID': sticker_id,
            'STKPKGID': sticker_package_id,
            'STKVER': sticker_version,
            'STKTXT': sticker_text,
        })
        self.client._send_message(message_object)

    def send_image(self, to, path):
        message = ttypes.Message(to=to, text=None)
        message.contentType = ttypes.ContentType.IMAGE
        message.contentPreview = None
        message.contentMetadata = None
        message_id = self.client._send_message(message).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': message_id,
            'size': len(open(path, 'rb').read()),
            'type': 'image',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.client.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload image failure.')
        else:  # r.content
            return True

    def send_video(self, to, path):
        message = ttypes.Message(to=to, text=None)
        message.contentType = ttypes.ContentType.VIDEO
        message.contentPreview = None
        message.contentMetadata = None
        message_id = self.client._send_message(message).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': message_id,
            'size': len(open(path, 'rb').read()),
            'type': 'video',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.client.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload video failure.')
        else:  # r.content
            return True

    def send_audio(self, to, path):
        message = ttypes.Message(to=to, text=None)
        message.contentType = ttypes.ContentType.AUDIO
        message.contentPreview = None
        message.contentMetadata = None
        message_id = self.client._send_message(message).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': message_id,
            'size': len(open(path, 'rb').read()),
            'type': 'audio',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.client.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload audio failure.')
        else:  # r.content
            return True

    def send_contact(self, to, mid):
        message = ttypes.Message(to=to, text="")
        message.contentType = ttypes.ContentType.CONTACT
        message.contentMetadata = {
            'mid': mid,
        }
        self.client._send_message(message)

    def send_location(self, to, long, lat, address):
        location = ttypes.Location(latitude=lat, longitude=long, address=address)
        message = ttypes.Message(to=to, text="Location", location=location)
        self.client._send_message(message)


class LineContact(LineBase):
    def __init__(self, client, contact):
        self.client = client
        self._contact = client
        self.id = contact.mid
        if contact.displayNameOverridden is None:
            self.name = contact.displayName
        else:
            self.name = contact.displayNameOverridden
        self.status_message = contact.statusMessage
        self.status = ttypes.ContactStatus._VALUES_TO_NAMES[contact.status]
        self.relation = ttypes.ContactRelation._VALUES_TO_NAMES[contact.relation]
        self.picture_path = contact.picturePath
        self.db_insert = {"uid": self.id, "name": self.name}

    def get_profile_image(self):
        return "http://dl.profile.line.naver.jp%s" % self.picture_path

    def block_contact(self):
        return self.client.block_contact(self.id)

    def unblock_contact(self):
        return self.client.unblock_contact(self.id)

    def delete_contact(self):
        pass

    def tag_contact(self, new_name):
        pass

    def __repr__(self):
        return "<LineContact name=%s status=%s>" % (self.name, self.status)


class LineRoom(LineBase):
    def __init__(self, client, room):
        self.client = client
        self._room = room
        self.id = room.mid
        self.created_time = room.createdTime
        self.members = [LineContact(client, contact) for contact in room.contacts]

    def leave_room(self):
        return self.client.leave_room(self.id)

    def invite_into_room(self, contact_mids):
        return self.client.invite_into_room(contact_mids)

    def update_add_members(self):
        pass

    def update_remove_members(self):
        pass

    def __repr__(self):
        return "<LineRoom id=%s (%s)>" % (self.id, len(self.members))


class LineGroup(LineBase):
    def __init__(self, client, group):
        self.client = client
        self._group = group
        self.id = group.id
        self.name = group.name
        self.joined_timestamp = group.createdTime
        if group.creator is not None:
            self.invited_by = LineContact(client, group.creator)
        else:
            self.invited_by = None
        self.join_by_url_prevented = group.preventedJoinByTicket
        try:
            # Comment the line below to speed it up
            #self.ticket = client.reissue_group_ticket(group.id)
            self.ticket = None
        except ttypes.TalkException:
            self.ticket = None
        if group.members is not None:
            self.members = [LineContact(client, contact) for contact in group.members]
            self.members.sort(key=operator.attrgetter("name"))
        else:
            self.members = []
        self.member_ids = []
        if group.invitee is not None:
            self.invitee = [LineContact(client, contact) for contact in group.invitee]
            self.invitee.sort(key=operator.attrgetter("name"))
        else:
            self.invitee = []
        self.invitee_ids = []

    def accept_group_invitation(self):
        return self.client.accept_group_invitation(self.id)

    def reject_group_invitation(self):
        return self.client.reject_group_invitation(self.id)

    def cancel_group_invitation(self, invitee_mids):
        return self.client.cancel_group_invitation(self.id, invitee_mids)

    def invite_into_group(self, contact_mids):
        return self.client.invite_into_group(self.id, contact_mids)

    def kick_out_from_group(self, member_mids):
        return self.client.kick_out_from_group(self.id, member_mids)

    def update_remove_members(self, contact_id):
        """Removes member from member list (used for kick operation)"""
        self.member_ids.remove(self.get_member_by_id(contact_id))
        return self.members.remove(self.get_member_by_id(contact_id))

    def update_remove_invitee(self, contact_id):
        """Removes invitee from invitee list (used for cancel operation)"""
        self.invitee_ids.remove(self.get_member_by_id(contact_id))
        return self.invitee.remove(self.get_invitee_by_id(contact_id))

    def update_add_members(self, contact_id):
        """Adds member to member list (used for join operation)"""
        self.members.append(self.client.get_contact_by_id(contact_id))
        self.member_ids.append(contact_id)
        return self.members.sort(key=operator.attrgetter("name"))

    def update_add_invitee(self, contact_id):
        """Adds invitee to invitee list (used for invite operation)"""
        self.invitee.append(self.client.get_contact_by_id(contact_id))
        self.invitee_ids.append(contact_id)
        return self.invitee.sort(key=operator.attrgetter("name"))

    def get_member_by_name(self, name):
        """Returns member by name"""
        for member in self.members:
            if member.name == name:
                return member
        return None

    def get_member_by_id(self, contact_id):
        """Returns member by contact"""
        for member in self.members:
            if member.id == contact_id:
                return member
        return None

    def get_invitee_by_name(self, name):
        """Returns invitee by name"""
        for invitee in self.invitee:
            if invitee.name == name:
                return invitee
        return None

    def get_invitee_by_id(self, contact_id):
        """Returns invitee by contact id"""
        for invitee in self.invitee:
            if invitee.id == contact_id:
                return invitee
        return None

    def get_group_link(self):
        if self.ticket is not None:
            return "line://ti/g/%s" % self.ticket
        else:
            self.ticket = self.client.reissue_group_ticket(self.id)
            return "line://ti/g/%s" % self.ticket

    def update_group_link(self):
        self.ticket = self.client.reissue_group_ticket(self.id)
        return self.get_group_link()

    def open_group_link(self):
        self._group.preventedJoinByTicket = False
        self.client.update_group(self._group)

    def close_group_link(self):
        self._group.preventedJoinByTicket = True
        self.client.update_group(self._group)

    def change_group_name(self, new_name):
        self._group.name = new_name
        self.client.update_group(self._group)

    def __repr__(self):
        return "<LineGroup name=%s (%s)>" % (self.name, len(self.members))
