# -*- coding: utf-8 -*-


class LineURL:

    proto = "https"
    protol = "http"
    port = 443
    host = "legy-jp.line.naver.jp"
    endpoints = {
        "LONG_POLLING": "P4",
        "NORMAL_POLLING": "NP4",
        "NORMAL": "S4",
        "COMPACT_MESSAGE": "C5",
        "REGISTRATION": "api/v4/TalkService.do",
        "NOTIFY_SLEEP": "F4",
        "NOTIFY_BACKGROUND": "B",
        "BUDDY": "BUDDY4",
        "SHOP": "SHOP4",
        "UNIFIED_SHOP": "TSHOP4",
        "STICON": "SC4",
        "CHANNEL": "CH4",
        "CANCEL_LONG_POLLING": "CP4",
        "SNS_ADAPTER": "SA4",
        "SNS_ADAPTER_REGISTRATION": "api/v4p/sa",
        "USER_INPUT": "",
        "USER_BEHAVIOR_LOG": "L1",
        "AGE_CHECK": "ACS4",
        "AGE_CHECK_REGISTRATION": "api/v4p/acs",
        "SPOT": "SP4",
        "CALL": "V4",
        "EXTERNAL_INTERLOCK": "EIS4",
        "TYPING": "TS",
        "CONN_INFO": "R3",
        "PAY": "PY4",
        "AUTH": "RS4",
        "AUTH_REGISTRATION": "api/v4p/rs",
        "SEARCH": "search/v1",
        "BEACON": "BEACON4",
        "PERSONA": "PS4",
        "SQUARE": "SQS1",
        "POINT": "POINT4",
        "COIN": "COIN4",
        "BAN": "BAN4",
        "BAN_REGISTRATION": "api/v4p/ban",
        "CERTIFICATE": "Q",
        "LINE_SESSION": "authct/v1/keys/line",
        "NAVER_SESSION": "authct/v1/keys/naver"
    }

    def __init__(self):
        pass

    def get_url(self):
        return "%s://%s" % (self.proto, self.host)

    def get_full_url(self, endpoint):
        return "%s://%s/%s" % (self.proto, self.host, self.endpoints[endpoint])

    def get_speed_url(self, endpoint):
        return "%s://%s/%s" % (self.protol, self.host, self.endpoints[endpoint])

    def get_login_url(self, endpoint):
        return "%s://%s/%s" % (self.proto, self.host, self.endpoints[endpoint])

    def get_endpoint(self, endpoint):
        return self.endpoints[endpoint]

    def get_endpoint_path(self, endpoint):
        return "/" + self.endpoints[endpoint]

    def get_port(self):
        return self.port

    def get_proto(self):
        return self.proto

    def get_host(self):
        return self.host


class LineHeaders:
    identifier_headers = {"User-Agent": None, "X-Line-Application": None, "X-Line-Access": None}
    static_headers = {"User-Agent": "Line/8.16.1", "X-Line-Application": "IOS 8.16.1 iphone7", "X-Line-Access": 'u3731f8d55416c510409258644c893625:aWF0OiAxNTQyOTcwMDA5MjkzCg==..s0TJZfcY4btd3jJjCPTJcHiBJ1E='}
    channel_headers = {"Content-Type": "application/json", "User-Agent": None, "X-Line-Mid": None, "x-lct": None}
    certificate_headers = {"User-Agent": None, "X-Line-Application": None}
    activity_headers = {"Content-Type": "application/json", "X-Line-Mid": None, "x-lct": None}
    upload_headers = {
        "User-Agent": None, "X-Line-Application": None, "Connection": "Keep-Alive", "Accept-Encoding": "gzip",
        "Content-Type": "application/x-www-form-urlencoded", "X-Line-Access": None}
    UA = {"android": "Line/2.5.0",
          "windows": "DESKTOP:WIN:5.9.0600-XP-x64(5.9.0)",
          "wp": "Line/5.11.3",
          "mac": "DESKTOP:MAC:5.9.0600-XP-x64(5.9.0)",
          "ipad": "Line/7.18.0 iPad6,3 10.2",
          "iphone": "Line/8.14.0",
          "win10": "Line/5.5.5",
          "tizen": "Mozilla/5.0 (Linux; Tizen 2.3; SAMSUNG SM-Z130H) AppleWebKit/537.3 (KHTML, like Gecko) Version/2.3 Mobile Safari/537.3",
          "fox": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/58.0.3029.110 Safari/537.36",
          "ios": "Line/8.14.0",
          "chrome": "Line/8.16.1"
          }
    LA = {"android": "ANDROIDLITE 2.5.0 Android 7.1.1",
          "windows": "DESKTOPWIN\t5.9.0\tWINDOWS\t5.9.0600-XP-x64",
          "wp": "WINPHONE 5.11.3 Lumia 10.0",
          "mac": "DESKTOPMAC\t5.9.0\tMbah\t5.9.0600-XP-x64",
          "ipad": "IOSIPAD\t7.18.0\tiPhone OS\t10.12.0",
          "iphone": 'IOS\t8.14.0\tiPhone OS\t12.0.0',
          "win10": "WIN10 5.5.5 oup12.1.1",
          "tizen": "TIZEN 1.4.3 Samsung2.3",
          "fox": "FIREFOXOS 1.4.11 Firefox_OS 1",
          "ios": 'IOS\t8.14.0\tiPhone OS\t12.0.0',
          "chrome": "CHROMEOS 2.1.5 Mbah12.1.1"
          }
    tokens = {}
    mid = None

    def __init__(self, device="iphone", tokens={}, mid=None):
        self.tokens = tokens
        self.mid = mid
        self.ready_headers(device)

    def ready_headers(self, device):
        self.identifier_headers["User-Agent"] = self.UA[device]
        self.identifier_headers["X-Line-Application"] = self.LA[device]
        self.certificate_headers["User-Agent"] = self.UA[device]
        self.certificate_headers["X-Line-Application"] = self.LA[device]
        self.channel_headers["User-Agent"] = self.UA[device]
        self.upload_headers["User-Agent"] = self.UA[device]
        self.upload_headers["X-Line-Application"] = self.LA[device]

    def update_headers(self, tokens={}, mid=None):
        self.tokens = tokens
        self.mid = mid
        self.identifier_headers["X-Line-Access"] = self.tokens["auth"]
        self.upload_headers["X-Line-Access"] = self.tokens["obs"]
        self.channel_headers["X-Line-Mid"] = self.mid
        self.activity_headers["X-Line-Mid"] = self.mid
        self.channel_headers["x-lct"] = self.tokens["channel"]
        self.activity_headers["x-lct"] = self.tokens["channel"]

    def update_android_header(self, line_version="2.5.0", android_version="7.1.2"):
        self.UA["iphone"] = "ANDROIDLITE %s Android%s" % (line_version, android_version)
        self.LA["iphone"] = "Line/%s" % line_version
    def get_header(self, h):
        return self.LA[h]