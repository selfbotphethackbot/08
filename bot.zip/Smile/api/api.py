# -*- coding: utf-8 -*-
import re,rsa
import requests
import pathlib
import traceback
from .settings import *
import LineService
from thrift.transport import THttpClient
try:
    import simplejson as json
except ImportError:
    import json

from thrift.transport.TTransport import TBufferedTransport as thrift_transport
from thrift.protocol.TCompactProtocol import TCompactProtocolAccelerated as thrift_protocol
from .services import talk, channel, channel_application_provided, message, ttypes, TalkService
from .transport import TPersistentHttpClient as thrift_client
from .timeline import LineTimeline

#with linepy
from akad.ttypes import IdentityProvider, LoginResultType, LoginRequest, LoginType
from akad import TalkService as talking
from .server import Server
from .session import Session

class LineAPI(object):
    LineUrlSettings = LineURL()
    LineTransport_poll = None
    LineProtocol_poll = None
    LineThriftClient_poll = None
    LineTransport_talk = None
    LineProtocol_talk = None
    LineThriftClient_talk = None
    LineTransport_channel = None
    LineProtocol_channel = None
    LineThriftClient_channel = None
    LineCertificate = None
    LineCertificateFile = ".line.crt"
    profile = None
    revision = None
    authToken = None
    timeline = None
    _messageReq = {}
    _unsendMessageReq = 0
    certificate = ""
    tokens = {"obs": None, "channel": None, "refresh": None, "unknown": None, "auth": None}

    def __init__(self, device):
        object.__init__(self)
        self._session = requests.session()
        self.LineHeaderSettings = LineHeaders(device)
        self.server = Server()
    """
    LOGIN METHODS
    """
    def connect(self):
        """
            SETS HEADERS AND CREATES THE CONNECTIONS TO THE LINE SERVER,
            EDIT THE HEADERS BELOW TO FIT YOUR NEEDS
            :return:
        """
        self.LineHeaderSettings.update_headers(self.tokens, self.profile.mid)
        client = thrift_client(self.LineUrlSettings.get_full_url("LONG_POLLING"))
        client.setCustomHeaders(self.LineHeaderSettings.identifier_headers)
        self.LineTransport_poll = thrift_transport(client)
        self.LineProtocol_poll = thrift_protocol(self.LineTransport_poll)
        self.LineTransport_poll.open()
        self.LineThriftClient_poll = talk.Client(self.LineProtocol_poll)
        client = thrift_client(self.LineUrlSettings.get_full_url("NORMAL"))
        client.setCustomHeaders(self.LineHeaderSettings.identifier_headers)
        self.LineTransport_talk = thrift_transport(client)
        self.LineProtocol_talk = thrift_protocol(self.LineTransport_talk)
        self.LineTransport_talk.open()
        self.LineThriftClient_talk = talk.Client(self.LineProtocol_talk)
        self.LineTransport_new = thrift_transport(client)
        self.LineProtocol_new = thrift_protocol(self.LineTransport_talk)
        self.LineTransport_new.open()
        self.LineThriftClient_new = talking.Client(self.LineProtocol_talk)
        self.LineTransport_nuke = thrift_client(self.LineUrlSettings.get_full_url("NORMAL"))
        self.LineTransport_nuke.setCustomHeaders(self.LineHeaderSettings.identifier_headers)
        self.LineThriftClient_nuke = thrift_protocol(self.LineTransport_nuke)
        self.LineTransport_nuke.open()
        self.get_tokens()

    def __loginRequest(self, type, data):
        lReq = LoginRequest()
        if type == '0':
            lReq.type = LoginType.ID_CREDENTIAL
            lReq.identityProvider = data['identityProvider']
            lReq.identifier = data['identifier']
            lReq.password = data['password']
            lReq.keepLoggedIn = data['keepLoggedIn']
            lReq.accessLocation = data['accessLocation']
            lReq.systemName = data['systemName']
            lReq.certificate = data['certificate']
            lReq.e2eeVersion = data['e2eeVersion']
        elif type == '1':
            lReq.type = LoginType.QRCODE
            lReq.keepLoggedIn = data['keepLoggedIn']
            if 'identityProvider' in data:
                lReq.identityProvider = data['identityProvider']
            if 'accessLocation' in data:
                lReq.accessLocation = data['accessLocation']
            if 'systemName' in data:
                lReq.systemName = data['systemName']
            lReq.verifier = data['verifier']
            lReq.e2eeVersion = data['e2eeVersion']
        elif type == '2':
            lReq.type = LoginType.ID_CREDENTIAL_WITH_E2EE
            lReq.identityProvider = data['identityProvider']
            lReq.identifier = data['identifier']
            lReq.password = data['password']
            lReq.keepLoggedIn = data['keepLoggedIn']
            lReq.accessLocation = data['accessLocation']
            lReq.systemName = data['systemName']
            lReq.certificate = data['certificate']
            lReq.e2eeVersion = data['e2eeVersion']
        else:
            lReq=False
        return lReq

    def getRecentMessages(self, chatId, count=10):
        return self.LineThriftClient_new.getRecentMessagesV2(chatId,count)
    def unsend_message(self, messageId):
        self._unsendMessageReq += 1
        return self.LineThriftClient_new.unsendMessage(self._unsendMessageReq, messageId)
    def loginmail(self, _id, passwd,device='windows',certificate=None):
        systemName="OUP-BOT"
        if self.server.EMAIL_REGEX.match(_id):
            self.provider = IdentityProvider.LINE_PHONE       # LINE
        else:
            self.provider = IdentityProvider.NAVER_KR   # NAVER

        self.server.setHeaders('X-Line-Application', self.LineHeaderSettings.get_header(device))
        self.tauth = Session(self.server.LINE_HOST_DOMAIN, self.server.Headers, self.server.LINE_AUTH_QUERY_PATH).Talk(isopen=False)

        rsaKey = self.tauth.getRSAKeyInfo(self.provider)
        message = (chr(len(rsaKey.sessionKey)) + rsaKey.sessionKey +
                   chr(len(_id)) + _id +
                   chr(len(passwd)) + passwd).encode('utf-8')
        pub_key = rsa.PublicKey(int(rsaKey.nvalue, 16), int(rsaKey.evalue, 16))
        crypto = rsa.encrypt(message, pub_key).hex()

        try:
            with open(_id + '.crt', 'r') as f:
                self.certificate = f.read()
        except:
            if certificate is not None:
                self.certificate = certificate
                if os.path.exists(certificate):
                    with open(certificate, 'r') as f:
                        self.certificate = f.read()

        self.auth = Session(self.server.LINE_HOST_DOMAIN, self.server.Headers, self.server.LINE_LOGIN_QUERY_PATH).Auth(isopen=False)

        lReq = self.__loginRequest('0', {
            'identityProvider': self.provider,
            'identifier': rsaKey.keynm,
            'password': crypto,
            'keepLoggedIn': True,
            'accessLocation': '127.0.0.1',
            'systemName': systemName,
            'certificate': self.certificate,
            'e2eeVersion': 0
        })

        result = self.auth.loginZ(lReq)
        print(result)

        if result.type == LoginResultType.REQUIRE_DEVICE_CONFIRM:
            #self.callback.PinVerified(result.pinCode)
            print("Enter pin code %s to your mobile phone within 2 minutes" % result.pinCode)
            self.server.setHeaders('X-Line-Access', result.verifier)
            getAccessKey = self.server.getJson(self.server.parseUrl(self.server.LINE_CERTIFICATE_PATH), allowHeader=True)
            print(getAccessKey)
            self.auth = Session(self.server.LINE_HOST_DOMAIN, self.server.Headers, self.server.LINE_LOGIN_QUERY_PATH).Auth(isopen=False)

            try:
                lReq = self.__loginRequest('1', {
                    'keepLoggedIn': True,
                    'verifier': getAccessKey['result']['verifier'],
                    'e2eeVersion': 0
                })
                result = self.auth.loginZ(lReq)
                print(result)
            except:
                raise Exception('Login failed')
            
            if result.type == LoginResultType.SUCCESS:
                if result.certificate is not None:
                    with open(_id + '.crt', 'w') as f:
                        f.write(result.certificate)
                    self.certificate = result.certificate
                if result.authToken is not None:
                    self.tokens["auth"] = result.authToken
                    self.LineHeaderSettings.update_headers(self.tokens)
                    self.token_login(result.authToken)
                else:
                    return False
            else:
                raise Exception('Login failed')

        elif result.type == LoginResultType.SUCCESS:
                    self.tokens["auth"] = result.authToken
                    self.LineHeaderSettings.update_headers(self.tokens)
                    self.token_login(result.authToken)

    def login(self, identity, password, qr=False, to_send=None,_client=None,device='ipad'):
        """
        LOGIN USING EMAIL AND PASSWORD
        :param identity:str()
        :param password:str()
        :return:
        """
        try:
            client = thrift_client(self.LineUrlSettings.get_full_url("REGISTRATION"))
            client.setCustomHeaders(self.LineHeaderSettings.certificate_headers)
            self.LineTransport_talk = thrift_transport(client)
            self.LineProtocol_talk = thrift_protocol(self.LineTransport_talk)
            self.LineTransport_talk.open()
            self.LineThriftClient_talk = TalkService.Client(self.LineProtocol_talk)
            if qr is True:
                result = self.LineThriftClient_talk.getAuthQrcode(True, "OUP-BOT")
                if to_send and _client:
                    _client.send_message(to_send, "line://au/q/" + result.verifier)
                else:
                    print("line://au/q/" + result.verifier)
                uri = self.LineUrlSettings.get_full_url("CERTIFICATE")
                self.tokens["auth"] = result.verifier
                self.LineHeaderSettings.update_headers(self.tokens)
                result = json.loads(self._session.get(url=uri, headers=self.LineHeaderSettings.identifier_headers).text)
                client = thrift_client(self.LineUrlSettings.get_full_url("AUTH_REGISTRATION"))
                client.setCustomHeaders(self.LineHeaderSettings.certificate_headers)
                self.LineTransport_talk = thrift_transport(client)
                self.LineProtocol_talk = thrift_protocol(self.LineTransport_talk)
                self.LineTransport_talk.open()
                self.LineThriftClient_talk = TalkService.Client(self.LineProtocol_talk)
                req = ttypes.LoginRequest(
                        type=ttypes.LoginType.QRCODE,
                        verifier=result['result']['verifier'],
                        keepLoggedIn=True,
                        systemName="OupBots",
                    )
                result = self.LineThriftClient_talk.loginZ(req)
                self.LineCertificate = result.certificate
                with open(self.LineCertificateFile, 'w') as f:
                    f.write(result.certificate)
                self.token_login(result.authToken)
            else:
                client.setPath(self.LineUrlSettings.get_endpoint_path("AUTH_REGISTRATION"))
                EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")
                if EMAIL_REGEX.match(identity):
                    provider = ttypes.IdentityProvider.LINE
                else:
                    provider = ttypes.IdentityProvider.NAVER_KR
                if pathlib.Path(self.LineCertificateFile).is_file():
                    with open(self.LineCertificateFile, "r") as f:
                        self.LineCertificate = f.read()
                req = ttypes.LoginRequest(
                    type=ttypes.LoginType.ID_CREDENTIAL,
                    identityProvider=provider,
                    identifier=identity,
                    password=password,
                    keepLoggedIn=True,
                    accessLocation="127.0.0.1",
                    systemName="OupBots",
                    certificate=self.LineCertificate
                )
                result = self.LineThriftClient_talk.loginZ(req)
                if result.type == 3:
                    client.setPath(self.LineUrlSettings.get_endpoint_path("REGISTRATION"))
                    print("Enter pin code %s to your mobile phone within 2 minutes" % result.pinCode)
                    uri = self.LineUrlSettings.get_full_url("CERTIFICATE")
                    self.tokens["auth"] = result.verifier
                    self.LineHeaderSettings.update_headers(self.tokens)
                    result = json.loads(
                        self._session.get(url=uri, headers=self.LineHeaderSettings.identifier_headers).text)
                    result = self.LineThriftClient_talk.loginWithVerifierForCerificate(result['result']['verifier'])
                    self.LineCertificate = result.certificate
                    with open(self.LineCertificateFile, 'w') as f:
                        f.write(result.certificate)
                    self.token_login(result.authToken)
                elif result.type == 1:
                    self.tokens["auth"] = result.authToken
                    self.LineHeaderSettings.update_headers(self.tokens)
                    self.token_login(result.authToken)
                else:
                    print("Error logging in")
                    exit()
        except ttypes.TalkException as e:
            print(e)
            traceback.print_exc()

    def token_login(self, token, main=True, os=None, app=None):
        """
        LOGIN USING AUTHTOKEN
        :param token:str()
        :return:
        """
        if main is True:
            self.LineHeaderSettings.update_android_header(app, os)
        self.tokens["auth"] = token
        self.LineHeaderSettings.update_headers(self.tokens)
        client = thrift_client(self.LineUrlSettings.get_full_url("REGISTRATION"))
        client.setCustomHeaders(self.LineHeaderSettings.identifier_headers)
        self.LineTransport_talk = thrift_transport(client)
        self.LineProtocol_talk = thrift_protocol(self.LineTransport_talk)
        self.LineThriftClient_talk = talk.Client(self.LineProtocol_talk)
        self.LineTransport_talk.open()
        self.profile = self.get_profile()
        self.revision = self.get_last_revision()
        self.authToken = token
        self.connect()

    def get_tokens(self):
        """
        GETS OTHER TOKENS
        :return:
        """
        self.tokens["obs"] = self.LineThriftClient_talk.acquireEncryptedAccessToken(1)
        client = thrift_client(self.LineUrlSettings.get_full_url("CHANNEL"))
        client.setCustomHeaders(self.LineHeaderSettings.identifier_headers)
        self.LineTransport_channel = thrift_transport(client)
        self.LineProtocol_channel = thrift_protocol(self.LineTransport_channel)
        self.LineThriftClient_channel = channel.Client(self.LineProtocol_channel)
        tokens = self.LineThriftClient_channel.issueChannelToken("1341209850")
        self.tokens["channel"] = tokens.channelAccessToken
        self.tokens["unknown"] = tokens.token
        self.tokens["refresh"] = tokens.refreshToken
        self.LineHeaderSettings.update_headers(self.tokens, self.profile.mid)
        self.timeline = LineTimeline(self.profile.mid, self.LineHeaderSettings.UA, self.LineHeaderSettings.LA, self.LineUrlSettings.get_url(), self.tokens)

    """
    GROUP METHODS
    """
    def get_groups(self, group_mids):
        """
        :param group_mids:list(str())
         GETS GROUP OBJECTS FROM LIST OF GROUP MIDS
        :return:list(ttypes.Group)
        """
        return self.LineThriftClient_talk.getGroups(group_mids)

    def get_group(self, group_mid):
        """
        :param group_mid:str()
        GETS GROUP OBJECT BY GROUP MID
        :return:ttypes.Group
        """
        return self.LineThriftClient_talk.getGroup(group_mid)

    def get_compact_group(self, group_mid):
        """
        :param group_mid:str()
        GETS GROUP OBJECT BY GROUP MID
        :return:ttypes.Group
        """
        return self.LineThriftClient_talk.getCompactGroup(group_mid)

    def get_joined_group_mids(self):
        """
        GETS A LIST OF GROUPS THE ACCOUNT IS A MEMBER OF
        :return group_mids:list(str())
        """
        return self.LineThriftClient_talk.getGroupIdsJoined()

    def get_invited_group_mids(self):
        """
        GETS A LIST OF GROUPS THE ACCOUNT IS INVITED TO
        :return group_mids: list(str())
        """
        return self.LineThriftClient_talk.getGroupIdsInvited()

    def kick_out_from_group(self, group_mid, member_mids=[]):
        """
        KICKS USERS FROM GROUP
        :param group_mid:str()
        :param member_mids:list(str())
        :return:
        """
        return self.LineThriftClient_talk.kickoutFromGroup(0, group_mid, member_mids)

    def cancel_group_invitation(self, group_mid, invitee_mids=[]):
        """
        CANCELS INVITATIONS TO GROUP
        :param group_mid:str()
        :param invitee_mids:list(str())
        :return:
        """
        return self.LineThriftClient_talk.cancelGroupInvitation(0, group_mid, invitee_mids)

    def reject_group_invitation(self, group_mid):
        """
        REJECTS PENDING INVITATION
        :param group_mid:str()
        :return:
        """
        return self.LineThriftClient_talk.rejectGroupInvitation(0, group_mid)

    def invite_into_group(self, group_mid, contact_mids=[]):
        """
        INVITE CONTACTS TO GROUP
        :param group_mid:str()
        :param contact_mids:list(str())
        :return:
        """
        return self.LineThriftClient_talk.inviteIntoGroup(0, group_mid, contact_mids)

    def accept_group_invitation(self, group_mid):
        """
        ACCEPTS PENDING INVITATION
        :param group_mid:str()
        :return:
        """
        return self.LineThriftClient_talk.acceptGroupInvitation(0, group_mid)

    def leave_group(self, group_mid):
        """
        LEAVES JOINED GROUP
        :param group_mid:str()
        :return:
        """
        return self.LineThriftClient_talk.leaveGroup(0, group_mid)

    def update_group(self, group_object):
        """
        UPDATES GROUP OBJECT ON THE LINE SERVER TO THE GROUP OBJECT YOU SENT
        :param group_object: ttypes.Group
        :return:
        """
        return self.LineThriftClient_talk.updateGroup(0, group_object)

    def reissue_group_ticket(self, group_mid):
        """
        GETS GROUP TICKET (LAST PART OFF GROUP URL) BY GROUP MID
        :param group_mid:str()
        :return:
        """
        return self.LineThriftClient_talk.reissueGroupTicket(group_mid)

    def accept_group_invitation_by_ticket(self, group_mid, ticket_id):
        """
        JOINS GROUP BY GROUP TICKET AND GROUP ID
        :param group_mid:str()
        :param ticket_id:str()
        :return:
        """
        return self.LineThriftClient_talk.acceptGroupInvitationByTicket(0, group_mid, ticket_id)

    def get_group_by_ticket(self, ticket_id):
        """
        GETS GROUP BY TICKET
        :param ticket_id:str()
        :return:ttypes.Group
        """
        return self.LineThriftClient_talk.findGroupByTicket(ticket_id)

    def create_group(self, name, contact_mids=[]):
        """
        CREATES GROUP WITH NAME WITH CONTACTS
        :param name:str()
        :param contact_mids:list(str())
        :return: ttypes.Group
        """
        return self.LineThriftClient_talk.createGroup(0, name, contact_mids)

    """
    ROOM METHODS
    """
    def get_room(self, room_mid):
        """
        GET ROOM OBJECT BY ROOM MID
        :param room_mid:str()
        :return: ttypes.Room
        """
        return self.LineThriftClient_talk.getRoom(room_mid)

    def get_compact_room(self, room_mid):
        """
        GET COMPACT ROOM OBJECT BY ROOM MID
        :param room_mid:str()
        :return: ttypes.Room
        """
        return self.LineThriftClient_talk.getCompactRoom(room_mid)

    def invite_into_room(self, room_mid, contact_mids=[]):
        """
        INVITE CONTACTS TO GROUP
        :param room_mid:str()
        :param contact_mids:list(str())
        :return:
        """
        return self.LineThriftClient_talk.inviteIntoRoom(room_mid, contact_mids)

    def create_room(self, contact_mids=[]):
        """
        CREATES ROOM WITH CONTACTS
        :param contact_mids:list(str())
        :return: ttypes.Group
        """
        return self.LineThriftClient_talk.createRoom(0, contact_mids)

    def leave_room(self, room_mid):
        """
        LEAVES JOINED ROOM
        :param room_mid:str()
        :return:
        """
        return self.LineThriftClient_talk.leaveRoom(0, room_mid)

    """
    CONTACT METHODS
    """
    def get_contacts(self, contact_mids=[]):
        """
        GET LIST OF CONTACT OBJECTS BY LIST OF CONTACT MIDS
        :param contact_mids:list(str())
        :return:list(ttypes.Contact)
        """
        return self.LineThriftClient_talk.getContacts(contact_mids)

    def get_contact(self, contact_mid):
        """
        GET CONTACT MID BY CONTACT MID
        :param contact_mid:str()
        :return:ttypes.Contact
        """
        return self.LineThriftClient_talk.getContact(contact_mid)

    def update_contact_setting(self, contact_mid, flag_int, value_string):
        """
        UPDATES CONTACT BY CONTACT SETTING SETTING FLAG AND VALUE
        :param contact_mid:str()
        :param flag_int:ttypes.ContactSetting
        :param value_string:str()
        :return:
        """
        return self.LineThriftClient_talk.updateContactSetting(0, contact_mid, flag_int, value_string)
    def delcon(self, contact):
        try:
            self.LineThriftClient_talk.updateContactSetting(16,contact,ttypes.ContactSetting.CONTACT_SETTING_DELETE,'True')
        except:
            traceback.print_exc()
        pass
    def block_contact(self, contact_mid):
        """
        BLOCKS CONTACT BY CONTACT MID
        :param contact_mid:str()
        :return:
        """
        return self.LineThriftClient_talk.blockContact(0, contact_mid)

    def unblock_contact(self, contact_mid):
        """
        UNBLOCKS CONTACT BY CONTACT MID
        :param contact_mid:str()
        :return:
        """
        return self.LineThriftClient_talk.unblockContact(0, contact_mid)

    """
    PROFILE/ACCOUNT METHODS
    """
    def get_all_contacts_ids(self):
        """
        GETS ALL CONTACT MIDS
        :return:list(str())
        """
        return self.LineThriftClient_talk.getAllContactIds()

    def get_favorite_mids(self):
        """
        GETS ALL FAVORITE CONTACT MIDS
        :return:list(str())
        """
        return self.LineThriftClient_talk.getFavoriteMids()

    def get_blocked_contact_ids(self):
        """
        GETS ALL  BLOCKED CONTACT MIDS
        :return:list(str())
        """
        return self.LineThriftClient_talk.getBlockedContactIds()

    def get_hidden_contact_mids(self):
        """
        GETS ALL HIDDEN CONTACT MIDS
        :return:list(str())
        """
        return self.LineThriftClient_talk.getHiddenContactMids()

    def get_blocked_recommendation_ids(self):
        """
        GETS ALL BLOCKED RECOMMENDATION CONTACT MIDS
        :return:list(str())
        """
        return self.LineThriftClient_talk.getBlockedRecommendationIds()

    def get_recommendation_ids(self):
        """
        GETS ALL RECOMMENDATION CONTACT MIDS
        :return:list(str())
        """
        return self.LineThriftClient_talk.getRecommendationIds()

    def get_profile(self):
        """
        GETS PROFILE OF THE ACCOUNT
        :return:ttypes.Profile
        """
        return self.LineThriftClient_talk.getProfile()

    def get_last_revision(self):
        """
        GET LAST OPERATION REVISION
        :return:int()
        """
        return self.LineThriftClient_talk.getLastOpRevision()

    def add_contact_by_mid(self, contact_mid):
        """
        ADDS CONTACT AS FRIEND BY CONTACT MID RETURNING THE CONTACT OBJECT
        :param contact_mid:str()
        :return:ttypes.Contact
        """
        return self.LineThriftClient_talk.findAndAddContactsByMid(0, contact_mid)

    def add_contact_by_email(self, contact_email):
        """
        ADDS CONTACT AS FRIEND BY CONTACT EMAIL RETURNING THE CONTACT OBJECT
        :param contact_email:str()
        :return:ttypes.Contact
        """
        return self.LineThriftClient_talk.findAndAddContactsByEmail(0, contact_email)

    def add_contact_by_user_id(self, contact_user_id):
        """
        ADDS CONTACT AS FRIEND BY CONTACT MID RETURNING THE CONTACT OBJECT
        :param contact_user_id:str()
        :return:ttypes.Contact
        """
        return self.LineThriftClient_talk.findAndAddContactsByUserid(0, contact_user_id)

    def add_contact_by_phone(self, contact_phone):
        """
        ADDS CONTACT AS FRIEND BY CONTACT MID RETURNING THE CONTACT OBJECT
        :param contact_phone:str()
        :return:ttypes.Contact
        """
        return self.LineThriftClient_talk.findAndAddContactsByPhone(0, contact_phone)

    def get_settings(self):
        """
        GETS ACCOUNT SETTINGS OBJECT
        :return: ttypes.Settings
        """
        return self.LineThriftClient_talk.getSettings()

    def update_settings(self, settings_object):
        """
        UPDATES ACCOUNT SETTINGS USING ACCOUNT SETTINGS
        :param settings_object:ttypes.Settings
        :return:
        """
        return self.LineThriftClient_talk.updateSettings(0, settings_object)

    def update_profile_attribute(self, attribute=int(), value=str()):
        return self.LineThriftClient_talk.updateProfileAttribute(0, attr=attribute, value=value)

    """
    MISCELLANEOUS METHODS
    """
    def _send_message(self, message_object):
        return self.LineThriftClient_talk.sendMessage(0, message_object)

    def sendMessage(self, to, text, contentMetadata={}, contentType=0):
        msg = ttypes.Message()
        msg.to, msg._from = to, self.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self._messageReq:
            self._messageReq[to] = -1
        self._messageReq[to] += 1
        return self.LineThriftClient_talk.sendMessage(self._messageReq[to], msg)
    def fetch_operations(self, count):
        return self.LineThriftClient_poll.fetchOperations(self.revision, count)

    def generate_user_ticket(self, expire_time, max_use):
        return self.LineThriftClient_talk.generateUserTicket(expire_time, max_use)

    def get_compact_contacts_modified_since(self, time_stamp):
        return self.LineThriftClient_talk.getCompactContactsModifiedSince(time_stamp)

    def get_rsa_key_info(self, provider):
        return self.LineThriftClient_talk.getRSAKeyInfo(provider)

    def get_last_announcement_index(self):
        return self.LineThriftClient_talk.getLastAnnouncementIndex()

    def fetch_announcements(self, last_fetched_index):
        return self.LineThriftClient_talk.fetchAnnouncements(last_fetched_index)

    def get_user_ticket(self):
        return self.LineThriftClient_talk.getUserTicket()

    def invalidate_user_ticket(self):
        return self.LineThriftClient_talk.invalidateUserTicket()

    def get_country_with_request_ip(self):
        return self.LineThriftClient_talk.getCountryWithRequestIp()

    def get_sessions(self):
        return self.LineThriftClient_talk.getSessions()

    def get_server_time(self):
        return self.LineThriftClient_talk.getServerTime()

    def get_system_configuration(self):
        return self.LineThriftClient_talk.getSystemConfiguration()

    def send_message_to_my_home(self, message_object):
        return self.LineThriftClient_talk.sendMessageToMyHome(0, message_object)
    def removeAllMessages(self, lastMessageId):
        return self.LineThriftClient_talk.removeAllMessages(0, lastMessageId)
    def remove_message_from_my_home(self, message_id):
        return self.LineThriftClient_talk.removeMessageFromMyHome(message_id)

    def reissue_device_credential(self):
        return self.LineThriftClient_talk.reissueDeviceCredential()

    def send_chat_checked(self, consumer, message_id):
        return self.LineThriftClient_talk.sendChatChecked(0, consumer, message_id)
    def nyeplitin(self,text,lp=''):
        separate = text.split(" ")
        if lp == '':adalah = text.replace(separate[0]+" ","")
        elif lp == 's':adalah = text.replace(separate[0]+" "+separate[1]+" ","")
        else:adalah = text.replace(separate[0]+" "+separate[1]+" "+separate[2]+" ","")
        return adalah
    def post_content(self, url, data=None, files=None):
        return self._session.post(url, headers=self.LineHeaderSettings.identifier_headers, data=data, files=files)
    def post_content1(self, url,headers=None, data=None, files=None):
        return self._session.post(url, headers=headers, data=data, files=files)
    def get_content(self, url, headers=None):
        return self._session.get(url,headers=self.LineHeaderSettings.identifier_headers,stream=True)
    """EXPERIMENTAL"""

    def kick_serialized(self, gid, uid):
        data = '\x82!\x00\x10kickoutFromGroup\x15\x00\x18!%s\x19\x18!%s\x00' % (gid, uid)
        self.LineTransport_nuke.flush_single(data.encode('raw_unicode_escape'))
    def message_serialized(self,gid,text):
        data = '\x82!\x00\x0bsendMessage\x15\x00\x1c(!%s\x88\x05%s\x00\x00' %(gid,text)
        self.LineTransport_nuke.flush_single(data.encode('raw_unicode_escape'))
    def kick_all_serialized(self, gid, uids):
        data = []
        for uid in uids:
            d = '\x82!\x00\x10kickoutFromGroup\x15\x00\x18!%s\x19\x18!%s\x00' % (gid, uid)
            data.append(d.encode())
        self.LineTransport_nuke.flush_multi(data)

    def invite_serialized(self, gid, uids):
        stuff = "!".join(uids)
        data = '\x82!\x00\x0finviteIntoGroup\x15\x00\x18!%s\x19X!%s\x00' % (gid, stuff)
        self.LineTransport_nuke.flush_single(data.encode())

    def cancel_serialized(self, gid, uids):
        stuff = "!".join(uids)
        data = '\x82!\x00\x0fcancelGroupInvitation\x15\x00\x18!%s\x19X!%s\x00' % (gid, stuff)
        self.LineTransport_nuke.flush_single(data.encode('latin-1'))

    def reject_serialized(self, gid):
        data = '\x82!\x00\x15rejectGroupInvitation\x15\x00\x18\x04%s\x00' % gid
        self.LineTransport_nuke.flush_single(data.encode())

    def opx_serialized(self, to):
        data = '\x82!\x00\x0bsendMessage\x15\x00\x1c(!%s\x88\x04test\x00\x00' % to
        self.LineTransport_nuke.flush_single(data.encode('latin-1'))

    def accept_serialized(self, gid):
        #data = '\x82!\x00\x15acceptGroupInvitation\x15\x00\x18\x04%s\x00' % gid
        data = '\x82!\x00\x15acceptGroupInvitation\x15\x00\x18!%s\x00' % gid
        self.LineTransport_nuke.flush_single(data.encode())

    def counter_invitation(self, gid, string):
        string = string.replace("\x1e", "!")
        data = '\x82!\x00\x0fcancelGroupInvitation\x15\x00\x18!%s\x19X!%s\x00' % (gid, string)
        self.LineTransport_nuke.flush_single(data.encode())
