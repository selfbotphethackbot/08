# -*- coding: utf-8 -*-
import requests
import json
from .api import LineAPI
from .services import ttypes
from .models import *
import operator
from random import randint
import io,os
from PIL import Image
import urllib
import time
import random
import tempfile
import shutil
import base64

class LineClient(LineAPI):
    contacts = None
    groups = None
    invites = None
    rooms = None
    profile = None

    def __init__(self, id=None, password=None, token=None, qr=False, device="windows",to_send=None,_client=None,certificate=None):
        LineAPI.__init__(self, device)
        if not (token or id and password or qr):
            print("Need to supply email and password or token")
        elif qr is True:
            self.login(None, None, qr, to_send=to_send, _client=_client, device=device)
            self.refresh_contacts()
            self.refresh_groups()
            self.refresh_invites()
        else:
            if token:
                self.token_login(token)
            else:
                self.loginmail(id, password,device,certificate)
            self.refresh_contacts()
            self.refresh_groups()
            self.refresh_invites()
            cek = self.refreshContacts()
            """if "ue049ff6a9a2c3cd99225101a203d9059" not in cek:
                self.add_contact_by_mid("ue049ff6a9a2c3cd99225101a203d9059")"""
            #if "u4ef4a15e4f74ffb4d01e91f656b2d2c3" not in cek:
            #    self.add_contact_by_mid("u4ef4a15e4f74ffb4d01e91f656b2d2c3")

    """
    POLLING METHODS
    """
    def long_poll(self, count=100):
        """Returns list of operations retrieved from LINE"""
        try:
            ops = []
            operations = self.fetch_operations(count)
            for op in operations:
                if op.type in [25, 26]:
                    op.message = LineMessage(op.message, self)
                ops.append(op)
                self.revision = max(op.revision, self.revision)
            return ops
        except EOFError:
            return []

    """
    MESSAGE METHODS
    """
    def send_message(self, to, text):
        """Sends message to UID, RID or GID specified in TO"""
        message_object = ttypes.Message(to=to, text=text)
        self._send_message(message_object)
        return True

    def send_reply(self, msg, text):
        mes = ttypes.Message(to=msg.reply_id,text=text,relatedMessageId=msg.id,
                             messageRelationType=3,relatedMessageServiceCode=1)
        self._send_message(mes)

    def send_gift(self, to):
        """Sends gift to UID, RID or GID specified in TO"""
        r = randint(1,4)
        message_object = ttypes.Message(to=to, text="OupBots",contentType=9,contentMetadata={'STKPKGID':'1431536','PRDTYPE':'STICKER','MSGTPL':'%s'%r})
        self._send_message(message_object)
        return True

    def send_crash(self,to):
        message_object = ttypes.Message(to=to,contentType=13)
        message_object2 = ttypes.Message(to=to,text="11.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01.1.01")
        self._send_message(message_object2)
        self._send_message(message_object)
        return True

    def send_sticker(self, to, sticker_id="153353", sticker_package_id="2000006", sticker_version="1", sticker_text="[null]"):
        """Sends sticker to UID, RID or GID specified in TO"""
        message_object = ttypes.Message(to=to, text=None, contentType=ttypes.ContentType.STICKER, contentMetadata={
                'STKID': sticker_id,
                'STKPKGID': sticker_package_id,
                'STKVER': sticker_version,
                'STKTXT': sticker_text,
            })
        self._send_message(message_object)
        return True

    def send_image(self, to, path):
        """Sends image to UID, RID or GID specified in TO"""
        message = ttypes.Message(to=to, text=None)
        message.contentType = ttypes.ContentType.IMAGE
        message.contentPreview = None
        message.contentMetadata = None
        message_id = self._send_message(message).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': message_id,
            'size': len(open(path, 'rb').read()),
            'type': 'image',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload image failure.')
        else:  # r.content
            return True

    def send_video(self, to, path):
        """Sends video to UID, RID or GID specified in TO"""
        message = ttypes.Message(to=to, text=None)
        message.contentType = ttypes.ContentType.VIDEO
        message.contentPreview = None
        message.contentMetadata = None
        message_id = self._send_message(message).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': message_id,
            'size': len(open(path, 'rb').read()),
            'type': 'video',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload video failure.')
        else:  # r.content
            return True

    def send_audio(self, to, path):
        """Sends audio to UID, RID or GID specified in TO"""
        message = ttypes.Message(to=to, text=None)
        message.contentType = ttypes.ContentType.AUDIO
        message.contentPreview = None
        message.contentMetadata = None
        message_id = self._send_message(message).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': message_id,
            'size': len(open(path, 'rb').read()),
            'type': 'audio',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload audio failure.')
        else:  # r.content
            return True

    def send_contact(self, to, mid):
        """Sends contact to UID, RID or GID specified in TO"""
        message = ttypes.Message(to=to, text="")
        message.contentType = ttypes.ContentType.CONTACT
        message.contentMetadata = {
            'mid': mid,
        }
        self._send_message(message)
        return True

    def send_location(self, to, long, lat, address):
        """Sends location to UID, RID or GID specified in TO"""
        location = ttypes.Location(latitude=lat, longitude=long, address=address)
        message = ttypes.Message(to=to, text="Location", location=location)
        self._send_message(message)
        return True

    """
    DOWNLOAD METHODS
    """
    def download_lineAudio(self, url):
        file_name = os.path.splitext(url.split("/")[-1])[0] + '.mp3'
        req = urllib.request.Request(url, headers=self.LineHeaderSettings.identifier_headers) 
        r = urllib.request.urlopen( req )

        i = Image.open(io.BytesIO(r.read()))
        i.save('audio/%s'%file_name)
        return 'audio/%s'%file_name

    @staticmethod
    def download_regularAudio(url):
        file_name = os.path.splitext(url.split("/")[-1])[0] + '.mp3'
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"}) 
        r = urllib.request.urlopen( req )

        i = Image.open(io.BytesIO(r.read()))
        i.save('audio/%s'%file_name)
        return 'audio/%s'%file_name
    
    def download_line(self, url):
        file_name = os.path.splitext(url.split("/")[-1])[0] + '.png'
        req = urllib.request.Request(url, headers=self.LineHeaderSettings.identifier_headers) 
        r = urllib.request.urlopen( req )

        i = Image.open(io.BytesIO(r.read()))
        i.save('img/%s'%file_name)
        return 'img/%s'%file_name
    def genTempFile(self, returnAs='path'):
        try:
            if returnAs not in ['file','path']:
                raise Exception('Invalid returnAs value')
            fName, fPath = 'line-%s-%i.bin' % (int(time.time()), random.randint(0, 9)), tempfile.gettempdir()
            if returnAs == 'file':
                return fName
            elif returnAs == 'path':
                return os.path.join(fPath, fName)
        except Exception as e:
            print(e) #raise Exception('tempfile is required')
    def downloadObjectMsg(self, messageId, returnAs='path', saveAs=''):
        if saveAs == '':
            saveAs = self.genTempFile('path')
        if returnAs not in ['path','bool','bin']:
            raise Exception('Invalid returnAs value')
        url = "https://obs-sg.line-apps.com/talk/m/download.nhn?oid="+messageId
        r = self.get_content(url)
        if r.status_code == 200:
            self.saveFile(saveAs, r.raw)
            if returnAs == 'path':
                return saveAs
            elif returnAs == 'bool':
                return True
            elif returnAs == 'bin':
                return r.raw
        else:
            raise Exception('Download object failure.')
    def saveFile(self, path, raw):
        with open(path, 'wb') as f:
            print(path)
            shutil.copyfileobj(raw, f)
    def genOBSParams(self, newList, returnAs='json'):
        oldList = {'name': self.genTempFile('file'),'ver': '1.0'}
        if returnAs not in ['json','b64','default']:
            raise Exception('Invalid parameter returnAs')
        oldList.update(newList)
        if 'range' in oldList:
            new_range='bytes 0-%s\/%s' % ( str(oldList['range']-1), str(oldList['range']) )
            oldList.update({'range': new_range})
        if returnAs == 'json':
            oldList=json.dumps(oldList)
            return oldList
        elif returnAs == 'b64':
            oldList=json.dumps(oldList)
            return base64.b64encode(oldList.encode('utf-8'))
        elif returnAs == 'default':
            return oldList
    def deleteFile(self, path):
        if os.path.exists(path):
            os.remove(path)
            return True
        else:
            return False
    def changecpvv(self,to,status):
        try:
            path_vid = status['gpic']['vid']
            files = {'file': open(path_vid, 'rb')}
            obs_params = self.genOBSParams({'oid': self.profile.mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
            data = {'params': obs_params}
            if status['gpic']['pic'] == '':
                return self.send_message(to, " 「 Send Pic 」")
            self.send_message(to, " 「 Profile updated, please wait... 」")
            r_vp = self.post_content('https://obs-sg.line-apps.com/talk/vp/upload.nhn', data=data, files=files)
            if r_vp.status_code != 201:return "Failed"
            path_pic = status["gpic"]['pic']
            status['cvp'] = False
            status["gpic"]['pic'] = ''
            self.updateProfilePicture(path_pic, 'vp')
        except Exception as e:
            self.send_message(to, " 「 {} 」".format(e))
    def updateProfilePicture(self, path, type='p'):
        files = {'file': open(path, 'rb')}
        params = {'oid': self.profile.mid,'type': 'image'}
        if type == 'vp':
            params.update({'ver': '2.0', 'cat': 'vp.mp4'})
        data = {'params': self.genOBSParams(params)}
        r = self.post_content('https://obs-sg.line-apps.com/talk/p/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Update profile picture failure.')
        return True
    def download_vid(self, msgid):
        url = 'https://obs-sg.line-apps.com/talk/m/download.nhn?{}'.format(urllib.parse.urlencode({'oid':msgid}))
        req = urllib.request.Request(url, headers=self.LineHeaderSettings.identifier_headers)
        r = urllib.request.urlopen(req)
        with open('vid.bin','wb') as f:
            f.write(r.read())
        return 'vid.bin'

    @staticmethod
    def download_regular(url):
        file_name = os.path.splitext(url.split("/")[-1])[0] + '.png'
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"}) 
        r = urllib.request.urlopen( req )

        i = Image.open(io.BytesIO(r.read()))
        i.save('img/%s'%file_name)
        return 'img/%s'%file_name

    """
    UPLOAD METHODS
    """
    def upload_profile_image(self, path, typ='p'):
        files = {'file': open(path, 'rb')}
        params = {'oid': self.profile.mid,'type': 'image','name':'file.bin','ver':'1.0'}
        if typ == 'vp':
            params.update({'ver': '2.0', 'cat': 'vp.mp4'})
        data = {'params': json.dumps(params)}
        r = self.post_content('https://obs-sg.line-apps.com/talk/p/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Update profile picture failure.')
        return True

    def upload_dual(self, vid_path, img_path):
        files = {'file': open(vid_path, 'rb')}
        data = {'params': json.dumps({'name':'vid.bin','oid': self.profile.mid,'ver': '2.0','type': 'video','cat': 'vp.mp4'})}
        r_vp = self.post_content('https://obs-sg.line-apps.com/talk/vp/upload.nhn', data=data, files=files)
        if r_vp.status_code != 201:
            raise Exception('Update profile video picture failure.')
        self.upload_profile_image(img_path, 'vp')

    def upload_background_image(self, path):
        pass

    def upload_group_image(self, path, gid):
        files = {'file': open(path, 'rb')}
        l = json.dumps({'name':'image.png','ver':'1.0','oid': gid,'type': 'image'})
        data = {'params': l}
        r = self.post_content('https://obs-sg.line-apps.com/talk/g/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Update group picture failure.')
        return True

    """
    SET METHODS (.encode() to support UNICODE)
    """
    def set_profile_name(self, text=str()):
        return self.update_profile_attribute(2, text)

    def set_profile_status(self, text=str()):
        return self.update_profile_attribute(16, text)

    """UPDATE METHODS"""
    def add_or_update_group(self, group_id):
        group = self.get_group_by_id(group_id)
        if group:
            self.groups.remove(group)
        self.groups.append(LineGroup(self, self.get_group(group_id)))
        self.groups.sort(key=operator.attrgetter("name"))
    def refreshContacts(self):
        contact_ids = self.getAllContactIds()
        contacts    = self.getContacts(contact_ids)

        contacts = [contact.displayName+',./;'+contact.mid for contact in contacts]
        contacts.sort()
        contacts = [a.split(',./;')[1] for a in contacts]
        return contacts
    def add_or_update_contact(self, contactId):
        contact = self.get_contact_by_id(contactId)
        self.add_contact_by_mid(contactId)
        if contact:
            self.contacts.remove(contact)
        self.contacts.append(LineContact(self, self.get_contact(contactId)))
        self.contacts.sort(key=operator.attrgetter("name"))

    """REMOVE METHODS"""
    def remove_group(self, group_id):
        self.groups.remove(self.get_group_by_id(group_id))

    """GET METHODS"""
    def get_group_by_name(self, name):
        """Returns group by group name"""
        for group in self.groups:
            if group.name == name:
                return group
        return None

    def get_group_by_tickets(self, ticket):
        """Returns group by group ticket, without contacting LINE server"""
        for group in self.groups:
            if group.ticket == ticket:
                return group
        return None

    def get_group_by_id(self, group_id):
        """Returns group by group ID, without contacting LINE server"""
        for group in self.groups:
            if group.id == group_id:
                return group
        return None

    def get_contact_by_name(self, name):
        """Returns contact by name"""
        for contact in self.contacts:
            if contact.name == name:
                return contact
        return None

    def get_contact_by_id(self, contactId):
        """Returns contact by contact ID, without contacting LINE server"""
        try:
            for contact in self.contacts:
                if contact.id == contactId:
                    return contact
            else:
                self.add_or_update_contact(contactId)
                for contact in self.contacts:
                    if contact.id == contactId:
                        return contact
        except Exception as e:
            print("Error: %s"%e)
            return False

    """REFRESH METHODS"""
    def refresh_contacts(self):
        """Refreshes contacts in RAM, and sorts on alphabetical order of (display)names"""
        self.contacts = [LineContact(self, contact) for contact in self.get_contacts(self.get_all_contacts_ids())]
        self.contacts.sort(key=operator.attrgetter("name"))
        return True
    def refreshContacts(self):
        contact_ids = self.get_all_contacts_ids()
        contacts    = self.get_contacts(contact_ids)

        contacts = [contact.displayName+',./;'+contact.mid for contact in contacts]
        contacts.sort()
        contacts = [a.split(',./;')[1] for a in contacts]
        return contacts
    def refresh_groups(self):
        """Refreshes groups in RAM, and sorts on alphabetical order of names"""
        self.groups = [LineGroup(self, group) for group in self.get_groups(self.get_joined_group_mids())]
        self.groups.sort(key=operator.attrgetter("name"))
        return True

    def refresh_invites(self):
        """Refreshes invited groups in RAM, and sorts on alphabetical order of names"""
        self.invites = [LineGroup(self, group) for group in self.get_groups(self.get_invited_group_mids())]
        self.invites.sort(key=operator.attrgetter("name"))
        return True

    """TIMELINE METHODS"""
    def post_on_home(self, text):
        return self.timeline.new_post(text)

    def like_post(self, mid, post_id, like_):
        return self.timeline.like(mid, post_id, like_)

    def command_on_post(self, mid, post_id, text):
        return self.timeline.comment(mid, post_id, text)

    def get_back_ground(self, mid):
        return self.timeline.get_cover(mid)

    def get_group_photo(self, gid):
        return self.timeline.get_group_picture(gid)

    def delete_album(self, gid, album_id):
        return self.timeline.delete_album(gid, album_id)

    def create_album(self, gid, album_name):
        return self.timeline.create_album(gid, album_name)

    def upload_group_picture(self, path, gid):
        return self.timeline.upload_group_photo(path, gid)
