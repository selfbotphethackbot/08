# -*- coding: utf-8 -*-
from helperBot.linepy import *
from helperBot.akad.ttypes import Message
from helperBot.akad.ttypes import ContentType as Type
from helerBot.akad.ttypes import ChatRoomAnnouncementContents
from helperBot.akad.ttypes import ChatRoomAnnouncement
from helperBot.akad.ttypes import Location
from helperBot.akad.ttypes import OpType
from Jplib.thrift.protocol import TCompactProtocol
from Jplib.thrift.transport import THttpClient
from Jplib.ttypes import LoginRequest
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from threading import Thread, activeCount
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from random import choice
from urllib.parse import urlencode
import subprocess as cmd
import time, random, sys, json, base64, subprocess, codecs, threading, LineService, shutil, glob, re, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
    
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

self = LINE('token Helper')
self.log("Auth Token : " + str(self.authToken))

mid = self.profile.mid
clientMID = self.profile.mid
clientPoll = OEPoll(self)
BotOpen = codecs.open("user.json","r","utf-8")
BotMaker = json.load(BotOpen)
Version = "HELPER PROTECTED"
settings = {
     "pict": {}
     }
def backupData():
    try:
        backup = BotMaker
        f = codecs.open('user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False

def logError(text):
    self.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError2.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))

def sendMentionFooter3(to, text="",ps='', mids=[]):
    arrData = ""
    arr = []
    mention = "@fenzz "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ''
        h = ''
        for mid in range(len(mids)):
            h+= str(texts[mid].encode('unicode-escape'))
            textx += str(texts[mid])
            if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
            else:slen = len(textx);elen = len(textx) + 13
            arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ''
        slen = len(textx)
        elen = len(textx) + 18
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    self.sendMessage(to, textx, {'AGENT_LINK': 'https://line.me/ti/p/~malespaipain','AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'AGENT_NAME': ps,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def Fenbot(op):
    try:
        wizard = BotMaker['wizard']
        rname = BotMaker['rname']
        botlist = BotMaker['myBot']
        if op.type is None:
            pass
        else :
            if op.type == 0:
                pass
            else :
                print("[ {} ] {}".format(str(op.type), OpType._VALUES_TO_NAMES[op.type]))

        if op.type == 26:
            msg = op.message
            msg_id = msg.id
            if msg.contentType == 1:
                if msg._from in wizard:
                    if settings['pict'] == True:
                       xpath = self.downloadObjectMsg(msg.id)
                       self.updateProfilePicture(xpath)
                       self.sendMessage(msg.to, "Picture profile has been update")
                       settings['pict'] = False
          
        if op.type == 13:
            if clientMID in op.param3:
               if op.param2 in wizard:
                self.acceptGroupInvitation(op.param1)
                self.sendMessage(op.param1, "Thank you for inviting me")
                
        if op.type in [25,26]:
            try:
                msg = op.message
                pesan = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != self.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        if pesan is None:
                            return
                        else:    	
                            if sender in wizard:
                                if pesan.lower().startswith("test"):
                                    self.findAndAddContactsByMid(sender)
                                    self.sendMessage(to,"Yes I'm Ready")
                                if pesan.lower() == "rname":
                                    self.sendMessage(to,rname)

                                if pesan.startswith(rname + "clear user "):
                                   mid = str(pesan.split(' ')[3])
                                   folder = str(pesan.split(' ')[2])                                
                                   try:
                                       del BotMaker['myBot'][mid]
                                       os.system('rm -rf {}'.format(str(folder)))
                                       self.sendMessage(to, "file username %s has been removed" %folder)
                                   except:
                                       self.sendMessage(to, "Not in user file")

                                if pesan.startswith(rname + "clear data "):
                                   folder = pesan.replace(rname+'clear data ','').split(' ')
                                   for x in folder:
                                       os.system('rm -rf {}.py'.format(x))
                                       time.sleep(2)
                                       self.sendMessage(to, "folder %s has been removed data" %x)
                                    
                                if pesan.startswith(rname +"run user "):
                                    user = pesan.replace(rname+'run user ','').split(' ')
                                    for x in user:
                                       try:
                                           os.system("screen -S {} -X quit".format(x))
                                           os.system('screen -dmS {}'.format(x))
                                           os.system('screen -r {} -X stuff "python3 {}.py \n"'.format(x, x))
                                           time.sleep(1)
                                           self.sendMessage(to, "%s Success Running Bots" %x)
                                       except:
                                           self.sendMessage(to,"Error")
                                           
                                if pesan.startswith(rname +"create user "):                                  
                                    user = str(pesan.split(' ')[2])
                                    mid = str(pesan.split(' ')[3])
                                    set_token = str(pesan.split(' ')[4])
                                    token = '  {"token": "%s"}' %str(set_token)
                                    try:
                                        BotMaker['myBot'][mid] = "%s"%user
                                        BotMaker['botmid'][user] = mid
                                        os.system('cp -r power.py {}.py'.format(user))
                                        time.sleep(1)
                                        self.sendMessage(to, "progres...!")
                                        os.system("cd token && echo -n '%s' > %s.json"%(token,user))
                                        os.system("screen -S {} -X quit".format(str(user)))
                                        os.system('screen -dmS {}'.format(user))
                                        os.system('screen -r {} -X stuff "python3 {}.py \n"'.format(user, user))
                                        time.sleep(1)
                                        self.sendMessage(to, "Succes to create and go to running %s" %user)
                                    except:
                                        self.sendMessage(to,"Error")
                                  
                                if pesan == rname + "reboot":
                                   self.sendMessage(to, "Rebooting")
                                   restart_program()
                                   print("REBOOT HELPER")

                                if pesan.startswith(rname + "clone "):
                                   folder = pesan.replace(rname+'clone ','').split(' ')
                                   for x in folder:                                   	
                                      os.system('cp -r power.py {}'.format(x))
                                      time.sleep(2)
                                      self.sendMessage(to, 'Succes clone folder to name %s'%x)
          
                                if pesan.startswith(rname + "killscreen "):
                                   screen = pesan.replace(rname+'killscreen ','').split(' ')
                                   for x in screen:
                                      os.system("screen -S {} -X quit".format(x))
                                      time.sleep(2)
                                      self.sendMessage(to, "Screen name %s Sucsess Logout Your Screen" %x)                                      
                                        
                                if pesan.startswith(rname +"cekuser "):
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    for target in targets:
                                        if target in BotMaker['myBot']:
                                               user = BotMaker['myBot'][target]
                                               _set = "Bot : @!\nUser name : {}".format(str(user))
                                               sendMentionFooter3(to, str(_set), ' B£∆CK_∆NG€£ ',  [target])
                                        else:                    	
                                               self.sendMessage(to,self.getContact(target).displayName+" not in list username")
                                           
                                if pesan == rname + "user list":
                                   if BotMaker["myBot"] == {}:
                                       self.sendMessage(to, "List username empity")
                                   else:                                   
                                       h = [a for a in BotMaker['myBot']]
                                       k = len(h)//100
                                       for aa in range(k+1):     	
                                          msgas = 'List Folder Name:\n'
                                          no=0
                                          for a in h:
                                             no+=1
                                             if BotMaker['myBot'][a] == "":cd = "None."
                                             else:cd = BotMaker['myBot'][a]
                                             if no == len(h):msgas+='\n{}. @!\nUsername:  ( {} )'.format(no,cd)
                                             else:msgas+='\n{}. @!\nUsername: ( {} )'.format(no,cd)
                                          msgas += "\n\nB£∆CK_∆NG€£ H€£P€R"
                                          sendMentionFooter3(to, msgas,' List User Name ', h)
                                    
                                if pesan == rname + "bots":
                                   if BotMaker["myBot"] == {}:
                                       self.sendMessage(to, "List folder empity")
                                   else:
                                       num = 0
                                       mc = ""
                                       for mi_d in BotMaker["myBot"]:
                                           mc += "%i - " % num + self.getContact(mi_d).displayName + "\n"
                                           num = (num+1)
                                       self.sendMessage(receiver, "Bots user:\n\n"+ mc + "\nB£∆CK_∆NG€£ H€£P€R")

                                if pesan == rname + "contact user":
                                   mc = []
                                   for mi_d in BotMaker["myBot"]:
                                     self.sendMessage(msg.to, None, contentMetadata={'mid': mi_d}, contentType=13)
                   
                                if pesan.startswith(rname +"getuser name "):
                                    username = pesan.split(" ")
                                    user = username[2]
                                    scont  = BotMaker['botmid'][user]
                                    try:
                                        self.sendContact(to,scont)
                                    except:
                                        self.sendMessage(to,"Error")                                

                                if pesan == rname + "allinvite user":
                                   for i in BotMaker["myBot"]:
                                      self.findAndAddContactsByMid(i)
                                      self.inviteIntoGroup(msg.to, [i])

                                if pesan.startswith(rname + "upname "):
                                   xres = pesan.replace(rname + "upname ","")
                                   if len(xres) <= 500:
                                      profile = self.getProfile()
                                      profile.displayName = xres
                                      self.updateProfile(profile)
                                      self.sendMessage(to, "Success update Name to " + xres)
                            
                                if pesan == rname + "up image":
                                   settings["pict"] = True
                                   self.sendMessage(to, "send your Image")
                            
                                if pesan == rname + "retreat all":
                                   gid = self.getGroupIdsJoined()
                                   for i in gid:
                                     self.leaveGroup(i)
                                   else:
                                     self.sendMessage(to," success leave all groups")
                            
                                if pesan == rname + "out":
                                   group = self.getGroup(to)
                                   self.leaveGroup(msg.to)
                                   
                                if pesan == rname + "free":
                                   process = os.popen('free -m')
                                   a = process.read()
                                   self.sendMessage(to, "{}".format(a))
                                   process.close()

                                if pesan == rname + "clear chace":
                                   process = os.popen('sync; echo 3 > /proc/sys/vm/drop_caches')
                                   a = process.read()
                                   self.sendMessage(to, "Done")
                                   process.close()

                                if pesan == rname + "screen list":
                                   proses = os.popen("screen -list")
                                   a = proses.read()
                                   self.sendMessage(to, "{}".format(str(a)))
                                   proses.close()
                                if "/ti/g/" in pesan.lower():
                                  link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                  links = link_re.findall(pesan)
                                  n_links = []
                                  for l in links:
                                    if l not in n_links:
                                      n_links.append(l)
                                  for ticket_id in n_links:
                                     group = self.findGroupByTicket(ticket_id)
                                     self.acceptGroupInvitationByTicket(group.id,ticket_id)
  
                                if pesan == rname + "menu":                                   
                                   commandlist = "🔰✰ᵇᵒᵗˢ✰ 🔰\n\n"
                                   num=0
                                   mycommands = [' menu',' test',' rname',' bots',' out',' reboot',' upname [nama contact]',' up image',' retreat all','create user [nama] [mid] [token]','run user [nama user]','cek user','user list','contact user','get user [nama user]','allinvite user','screen list','kill screen','clear chace']
                                   mycommands = ['. '+rname + o for o in mycommands]
                                   mycommands2 = ['. Rname']
                                   num=(num+1)
                                   for cmd in mycommands:
                                      commandlist += "\n%i%s"%(num,cmd)
                                      num=(num+1)
                                   for cmd in mycommands2:
                                      commandlist += "\n%i%s"%(num,cmd)
                                      num=(num+1)
                                   self.sendMessage(msg.to, commandlist)
            except Exception as error:
                logError(error)
                traceback.print_tb(error.__traceback__)

        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
                                                                                  
while True:
    try:
        ops = clientPoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                Fenbot(op)
                clientPoll.setRevision(op.revision)
    except Exception as error:
        logError(error)
